import React, { Component } from 'react';
import { View, Text, ActivityIndicator, FlatList, TouchableOpacity, StyleSheet, Image } from 'react-native';
import axios from 'axios';
import Header from './Header'; // Import the Header component

class CategoryScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      categories: [],
      loading: true,
    };
  }

  componentDidMount() {
    this.fetchCategories();
  }

  fetchCategories = async () => {
    try {
      const response = await axios.post('https://webcruiser.in/greencard/q3.php', {
        action: 'listcategories',
      });
      this.setState({ categories: response.data, loading: false });
    } catch (error) {
      console.error('Error fetching categories:', error);
      this.setState({ loading: false });
    }
  };

  handleCategoryPress = (category, color) => {
    const { navigation } = this.props;
    console.log("Navigating with category ID:", category); // Log the entire category object
    navigation.navigate('Slide', { category, color });
  };

  getBackgroundColor = (index) => {
    const colors = ['#FFB6C1', '#ADD8E6', '#90EE90', '#FFD700', '#FF7F50', '#6A5ACD'];
    return colors[index % colors.length];
  };

  // Function to get SVG path based on category name
  getCategoryIcon = (categoryName) => {
    switch (categoryName.toLowerCase()) {
      case 'general':
        return require('../assets/icon/General.png'); // Local SVG file path
      case 'daily life':
        return require('../assets/icon/Daily-life.png'); // Local SVG file path
		 case 'family':
        return require('../assets/icon/Family.png'); // Local SVG file path
		 case 'finances':
        return require('../assets/icon/Finances.png'); // Local SVG file path
		 case 'wedding':
        return require('../assets/icon/Wedding.png'); // Local SVG file path
		 case 'relationship history':
        return require('../assets/icon/Relationship-history.png'); // Local SVG file path
		 case 'household':
        return require('../assets/icon/Household.png'); // Local SVG file path
		 case 'living conditions':
        return require('../assets/icon/Living-conditions.png'); // Local SVG file path
		 case 'future plans':
        return require('../assets/icon/Future-plans.png'); // Local SVG file path
		
      default:
        return require('../assets/icon/App-Icon.png'); // Default SVG if no match
    }
  };

  render() {
    const { categories, loading } = this.state;
    const { navigation } = this.props; // Destructure navigation

    if (loading) {
      return (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#1dbf73" />
        </View>
      );
    }

    return (
      <View style={{ flex: 1 }}>
        {/* Display the custom header */}
        <Header navigation={navigation} />

        <FlatList
          data={categories}
          keyExtractor={(item) => item.id.toString()}
          numColumns={2} // Display 2 items per row
          renderItem={({ item, index }) => {
            const backgroundColor = this.getBackgroundColor(index);
            const categoryIcon = this.getCategoryIcon(item.category_name); // Get the SVG based on category name
            return (
              <TouchableOpacity onPress={() => this.handleCategoryPress(item, backgroundColor)}>
                <View style={[styles.categoryItem, { backgroundColor }]}>
                  
                  {/* SVG Icon above category name */}
                  <Image
                    source={categoryIcon} 
                    style={styles.categoryIcon}
                    resizeMode="contain"
                  />

                  {/* Category Name */}
                  <Text style={styles.categoryText}>{item.category_name}</Text>
				  <Text style={styles.categoryText}>{item.question_count}</Text>
                </View>
              </TouchableOpacity>
            );
          }}
        />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  categoryItem: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    height: 150,
    minWidth: '50%',
  },
  categoryIcon: {
    width: 50, // Set the size of the SVG icon
    height: 50,
    marginBottom: 10,
  },
  categoryText: {
    fontSize: 13,
    color: '#fff',
  },
});

export default CategoryScreen;
