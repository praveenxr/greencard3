import React, { useContext } from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import HomeStack from './HomeStack';
import HelpScreen from './HelpScreen';
import QuestionListScreen from './QuestionListScreen';
import { AuthContext } from './AuthContext'; // Import AuthContext

const Tab = createBottomTabNavigator();

const AppTabs = () => {
  const { isLoggedIn } = useContext(AuthContext); // Access login state

  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconName;

          if (route.name === 'Home') {
            iconName = focused ? 'home' : 'home-outline';
          } else if (route.name === 'Help') {
            iconName = focused ? 'help' : 'help-outline';
          } else if (route.name === 'Questions') {
            iconName = focused ? 'list' : 'list-outline';
          }

          return <Ionicons name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: '#1dbf73',
        tabBarInactiveTintColor: 'gray',
      })}
    >
      <Tab.Screen name="Home" component={HomeStack} options={{ headerShown: false }} />
      <Tab.Screen name="Help" component={HelpScreen} />
      {/* Conditionally render Questions tab if user is logged in */}
      {isLoggedIn && (
        <Tab.Screen 
          name="Questions" 
          component={QuestionListScreen} 
          options={{ headerShown: false }} // Hide header for Questions screen
        />
      )}
    </Tab.Navigator>
  );
};

export default AppTabs;
