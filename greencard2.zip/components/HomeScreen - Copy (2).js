import React, { Component } from 'react';
import { StatusBar } from "expo-status-bar";
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { ListItem, Icon, Overlay } from 'react-native-elements';
import { Video } from 'expo-av';
import MenuDrawer from 'react-native-side-drawer';
import {
  ImageBackground,
  StyleSheet,
  Text,
  View,
  Image,
  SafeAreaView,
  TouchableOpacity,
} from "react-native";
import { Header } from 'react-native-elements';
import Swiper from 'react-native-swiper';

import WebsiteQuoteForm from './WebsiteQuoteForm';

const Tab = createBottomTabNavigator();

const questions = [
  { id: 1, question: 'What is the capital of France?', answer: 'Paris' },
  { id: 2, question: 'What is 2 + 2?', answer: '4' },
  { id: 3, question: 'Who wrote "To be, or not to be"?', answer: 'William Shakespeare' },
];

class QuestionSlide extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showAnswer: false,
    };
  }

  toggleAnswer = () => {
    this.setState((prevState) => ({ showAnswer: !prevState.showAnswer }));
  };

  render() {
    const { question, answer } = this.props.item;
    const { showAnswer } = this.state;

    return (
      <View style={styles.slide}>
        <Text style={styles.question}>{question}</Text>
        {showAnswer && <Text style={styles.answer}>{answer}</Text>}
        <TouchableOpacity onPress={this.toggleAnswer}>
          <Text style={styles.flashcardButton}>
            {showAnswer ? 'Hide Answer' : 'Show Answer'}
          </Text>
        </TouchableOpacity>
      </View>
    );
  }
}

export default class Homescreen extends Component {
  constructor(props) {
    super(props);
    this.video = React.createRef();

    // State initialization
    this.state = {
      images: [
        require('.././assets/slide.png'),
        require('.././assets/slide2.jpg'),
        require('.././assets/slide3.png'),
        require('.././assets/slide4.png'),
      ],
      open: false,
      visible: false,
      status: '',
      list: [
        { name: 'Website', icon: 'laptop', subtitle: 'Wordpress or Custom' },
        { name: 'Logo', icon: 'paint-brush', subtitle: 'Vector or Flat' },
        { name: 'APP', icon: 'mobile', color: '#517fa4', subtitle: 'Android or iOS' },
        { name: 'Landingpage', icon: 'mobile', color: '#517fa4', subtitle: 'Wordpress' },
      ],
      menu: [
        { icon: 'suitcase', name: 'Portfolio' },
        { name: 'Logo', icon: 'paint-brush' },
        { name: 'Website', icon: 'laptop' },
        { name: 'APP', icon: 'mobile' },
        { name: 'Landingpage', icon: 'rocket' },
      ],
    };
  }

  // Function for menu items
  MenuNavigation = (menu_item) => {
    const { navigation } = this.props;

    if (menu_item === 'Portfolio') {
      navigation.navigate('Portfolio');
    } else if (menu_item === 'Website') {
      navigation.navigate('WebsiteQuoteForm', {
        itemId: menu_item,
        otherParam: 'anything you want here',
      });
    } else if (menu_item === 'APP') {
      navigation.navigate('APPQuoteForm', { itemId: menu_item });
    } else if (menu_item === 'Logo') {
      navigation.navigate('Logos', { itemId: menu_item });
    } else if (menu_item === 'Landingpage') {
      navigation.navigate('Landingpage', { itemId: menu_item });
    }
  };

  // Function for navigating to quote forms
  QuoteformNavigation = (service_type) => {
    const { navigation } = this.props;

    if (service_type === 'Website') {
      navigation.navigate('WebsiteQuoteForm', {
        itemId: service_type,
        otherParam: 'anything you want here',
      });
    } else if (service_type === 'APP') {
      navigation.navigate('APPQuoteForm', { itemId: service_type });
    } else if (service_type === 'Logo') {
      navigation.navigate('Logos', { itemId: service_type });
    } else if (service_type === 'Landingpage') {
      navigation.navigate('Landingpage', { itemId: service_type });
    }
  };

  // Header left icon
  headerleftIcon = () => (
    <View>
      <Icon name="menu" color="black" onPress={this.toggleOpen} />
    </View>
  );

  // Header center component
  headerCenter = () => (
    <View>
      <Image
        source={require('.././assets/uvdlogo3.png')}
        style={{ width: 250, height: 50, resizeMode: 'contain' }}
      />
    </View>
  );

  // Toggle drawer
  toggleOpen = () => {
    this.setState({ open: !this.state.open });
  };

  // Drawer content
  drawerContent = () => (
    <View style={styles.animatedBox}>
      <TouchableOpacity onPress={this.toggleOpen}>
        <Text>Close</Text>
      </TouchableOpacity>
      {this.state.menu.map((l, i) => (
        <ListItem
          style={{ width: 170, marginLeft: -20 }}
          key={i}
          bottomDivider
          onPress={() => this.MenuNavigation(l.name)}
        >
          <Icon name={l.icon} style={{ fontSize: 5 }} color="black" type="font-awesome" />
          <ListItem.Content>
            <ListItem.Title style={{ fontSize: 15, width: 270, marginRight: 100 }}>
              {l.name}
            </ListItem.Title>
          </ListItem.Content>
          <ListItem.Chevron />
        </ListItem>
      ))}
    </View>
  );

  render() {
    const { visible } = this.state;

    return (
      <SafeAreaView>
        <Header
          style={{ height: 10, backgroundColor: 'white', opacity: 0.9 }}
          leftComponent={this.headerleftIcon}
          centerComponent={this.headerCenter}
          containerStyle={{
            backgroundColor: 'white',
            justifyContent: 'space-around',
          }}
        />
        <View>
          <MenuDrawer
            open={this.state.open}
            drawerContent={this.drawerContent()}
            drawerPercentage={45}
            animationTime={250}
            overlay={true}
            opacity={0.4}
            style={{ backgroundColor: 'black' }}
          >
            <View>
              <Overlay
                isVisible={visible}
                onBackdropPress={() => this.setState({ visible: !this.state.visible })}
              >
                <View>
                  {/* Overlay Content */}
                </View>
              </Overlay>
            </View>

     

            {/* Swiper component for questions */}
            <Swiper showsButtons loop={false}>
              {questions.map((item) => (
                <QuestionSlide key={item.id} item={item} />
              ))}
            </Swiper>

          </MenuDrawer>
        </View>
      </SafeAreaView>
    );
  }
}

// Styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  animatedBox: {
    flex: 1,
    backgroundColor: 'white',
    padding: 10,
    opacity: 0.8,
  },
  slide: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f9c2ff',
    borderWidth: 5,
    margin: 30,
    marginBottom:150,
  },
  question: {
    fontSize: 18,
    marginBottom: 10,
    textAlign: 'center',
  },
  answer: {
    fontSize: 16,
    color: 'gray',
    marginTop: 10,
    textAlign: 'center',
  },
  flashcardButton: {
    marginTop: 20,
    fontSize: 16,
    color: '#1dbf73',
  },
});
