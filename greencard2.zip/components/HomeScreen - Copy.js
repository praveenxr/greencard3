import React, { Component } from 'react';
import { StatusBar } from "expo-status-bar";
import { useState } from "react";
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import WebsiteQuoteForm from './WebsiteQuoteForm';

import { ListItem, Icon , Overlay,Dimensions  } from 'react-native-elements';
import { Video } from 'expo-av';
import MenuDrawer from 'react-native-side-drawer';
//import { SliderBox } from "react-native-image-slider-box";
  
  
import {ImageBackground,
    StyleSheet,
    Text,
    View,
    Image,
    TextInput,
    Button,
    TouchableOpacity,
    Alert,SafeAreaView,ScrollView,
  } from "react-native";
 
  import { Header } from 'react-native-elements';
export default class Homescreen extends Component {
 
  constructor(props) {
    super(props);
    this.video = React.createRef();
  }
 
  //States declaration 

  state = {
    images: [
      require('.././assets/slide.png'),          
      require('.././assets/slide2.jpg'),          
      require('.././assets/slide3.png'),          
      require('.././assets/slide4.png'),          
        
    ],
    open:false,
    visible:false,
    setVisible:'',

    status:'',
    setStatus:'',
    list : [ // Service list details array 
     {
       name: 'Website',
       icon: 'laptop',
       subtitle: 'Wordpress or Custom'
     },
     {
       name: 'Logo',
       icon: 'paint-brush',
       subtitle: 'Vector or Flat'
     },
     {
      name: 'APP',
      icon: 'mobile',
      color:'#517fa4',
      subtitle: 'Android or iOS'
    },
    {
      name: 'Landingpage',
      icon: 'mobile',
      color:'#517fa4',
      subtitle: 'Wordpress'
    },
    
     
   ],
   menu : [ // Service list details array 
    {
     
      icon: 'suitcase',
      name: 'Portfolio',
    },
    {
      name: 'Logo',
      icon: 'paint-brush',
    
    },
    {
      name: 'Website',
      icon: 'laptop',
    
    },
    {
      name: 'APP',
      icon: 'mobile',
    
    },
    {
      name: 'Landingpage',
      icon: 'rocket',
    
    },
  
   
    
  ]
 }

 
 //Function for menu items  

 MenuNavigation = (menu_item) =>{
  
  if(menu_item==='Portfolio')
  {
    this.props.navigation.navigate('Portfolio');
  }

  if(menu_item==='Website')
  {
    this.props.navigation.navigate('WebsiteQuoteForm' ,{
      itemId: menu_item,
      otherParam: 'anything you want here',
    });
  
  }
  if(menu_item==='APP')
  {
    this.props.navigation.navigate('APPQuoteForm' ,{
      itemId: menu_item,
     // otherParam: 'anything you want here',
    });
  
  }

  if(menu_item==='Logo')
  {
    this.props.navigation.navigate('Logos' ,{
      itemId: menu_item,
    //  otherParam: 'anything you want here',
    });
  
  }
  if(menu_item==='Landingpage')
  {
    this.props.navigation.navigate('Landingpage' ,{
      itemId: menu_item,
    //  otherParam: 'anything you want here',
    });
  
  }


}




 //Function for Navigate to   web , app , quote , Quote forms  

 QuoteformNavigation = (service_type) =>{
  
  if(service_type==='Website')
  {
    this.props.navigation.navigate('WebsiteQuoteForm' ,{
      itemId: service_type,
      otherParam: 'anything you want here',
    });
  
  }
  if(service_type==='APP')
  {
    this.props.navigation.navigate('APPQuoteForm' ,{
      itemId: service_type,
     // otherParam: 'anything you want here',
    });
  
  }

  if(service_type==='Logo')
  {
    this.props.navigation.navigate('Logos' ,{
      itemId: service_type,
    //  otherParam: 'anything you want here',
    });
  
  }
  if(service_type==='Landingpage')
  {
    this.props.navigation.navigate('Landingpage' ,{
      itemId: service_type,
    //  otherParam: 'anything you want here',
    });
  
  }

    } 
 headerleftIcon = () => {
  return (
    <View>
{/*<TouchableOpacity onPress={this.toggleOpen} style={styles.body}>*/}
<Icon
  name='menu'
  
  color='black'
  onPress={this.toggleOpen}
/>

       {/*   </TouchableOpacity>*/}
       </View>
           );
 }
 headerCenter = () => {
  return (
    <View>
<Image
  source={require('.././assets/uvdlogo3.png')}
  style={{ width: 250,height:50,resizeMode:'contain' }}
/>






       </View>
           );
 } 
 
 toggleOpen = () => {
      this.setState({ open: !this.state.open });
    };
   
    drawerContent = () => {
      return (
             <View style={styles.animatedBox}><TouchableOpacity onPress={this.toggleOpen} ><Text>Close</Text>
        </TouchableOpacity>
        { /*Service List Starts Here*/ } 
  {
    this.state.menu.map((l, i) => (
      <ListItem style={{width:170,marginLeft:-20}} key={i} bottomDivider  onPress={() =>this.MenuNavigation(l.name)}>
        <Icon name={l.icon} style={{fontSize:5}} color='black' type='font-awesome'/>
        <ListItem.Content >
          <ListItem.Title style={{fontSize:15,width:270,marginRight:100}}>{l.name}</ListItem.Title>
       
        </ListItem.Content>
        <ListItem.Chevron />
      </ListItem>
    ))
  }
  { /*Service List Ends Here*/ } 
        </View>
        
      );
    };

  render() {


const Tab = createBottomTabNavigator();
    const {visible, setStatus,status} = this.state;
    const { width } = 500;
     
    return (
      <SafeAreaView >
       
         <Header style={{ height: 10, backgroundColor: 'white', opacity: 0.9 }}
leftComponent={this.headerleftIcon}
  centerComponent={this.headerCenter}
 // rightComponent={{ icon: 'home', color: 'black' }}
  containerStyle={{
    backgroundColor: 'white',
    justifyContent: 'space-around',
  }}
  />
  
      <View >
    
     
            

        <MenuDrawer 
          open={this.state.open} 
          drawerContent={this.drawerContent()}
          drawerPercentage={45}
          animationTime={250}
          overlay={true}
          opacity={0.4}
          style={{backgroundColor:'black',}}
        >
       
       
        
          { /*Over Lay starts Here*/ }  
            <View>
          
           
     
      <Overlay isVisible={visible} onBackdropPress={() => this.setState({visible: !this.state.visible})}>
      <View>
      <View>
      
      </View>
      
    
      </View>
      </Overlay>
    </View>   
    { /*OverLay End Here*/ } 


  
    {/*<ImageBackground source={require('../assets/slide.png')} style={styles.images}>
        
   
      
     
  </ImageBackground>
        */}
  <View>
  

  <Text style={{fontSize:20,marginTop:15,marginLeft:20,marginBottom:10}}> Our Services</Text>
  
 
</View>


</MenuDrawer>
  
  </View>
  


 </SafeAreaView>  
    )  



  }

  
}

 
//Styles 

const styles = StyleSheet.create({
  container: {
    flex: 1,
    
  },
  animatedBox: {
    flex: 1,
    backgroundColor: "white",
    padding: 10,
    
    opacity:.8
  },
  body: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'black'
  },
  backgroundimage: {
    flex: 1,
    resizeMode: "cover",
    justifyContent: "center",
   
  },
  images: {
    resizeMode: "contain",
    
    height:210,
    marginTop:0
    


  },
  image: {
    marginBottom: 40,
  },
 
  inputView: {
  
    backgroundColor: "white",
    borderRadius: 30,
    width: "70%",
    height: 45,
    marginBottom: 20,
 
    alignItems: "center",
  },
 
  TextInput: {
    height: 50,
    flex: 1,
    padding: 10,
    marginLeft: 20,
  },
 
  forgot_button: {
    height: 30,
    marginBottom: 30,
    color:'white',
  },
 
  loginBtn: {
    width: "80%",
    borderRadius: 25,
    height: 50,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 40,
    backgroundColor: "#1dbf73",
    color:'white'
  },
  backgroundVideo: {
    position: 'absolute',
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
  },
  video: {
    alignSelf: 'center',
    width: 320,
    height: 200,
  },
});
