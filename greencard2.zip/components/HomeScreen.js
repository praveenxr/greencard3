import React, { Component } from 'react';
import axios from 'axios';

import { ListItem, Icon, Overlay } from 'react-native-elements';

import MenuDrawer from 'react-native-side-drawer';
import { ActivityIndicator } from 'react-native';
import {
  ImageBackground,
  StyleSheet,
  Text,
  View,
  Image,
  SafeAreaView,
  TouchableOpacity,
} from "react-native";
import { Header } from 'react-native-elements';
import Swiper from 'react-native-swiper';





const QuestionSlide = ({ item }) => {

  const { category = "General", question = "No question provided", answer = "No answer available" } = item;

  const toggleAnswer = () => {
    setShowAnswer(!showAnswer);
  };

  return (
    <View style={styles.slide}>
      <Text style={styles.category}>{category}</Text>
      <Text style={styles.question}>{question}</Text>
    
    </View>
  );
};


export default class Homescreen extends Component {
  constructor(props) {
    super(props);
    this.video = React.createRef();

    // State initialization
    this.state = {
     
      open: false,
      visible: false,
      status: '',
      list: [
        { name: 'Website', icon: 'laptop', subtitle: 'Wordpress or Custom' },
        { name: 'Logo', icon: 'paint-brush', subtitle: 'Vector or Flat' },
        { name: 'APP', icon: 'mobile', color: '#517fa4', subtitle: 'Android or iOS' },
        { name: 'Landingpage', icon: 'mobile', color: '#517fa4', subtitle: 'Wordpress' },
      ],
      menu: [
        { icon: 'home', name: 'Home' },
        
      ],
      questions: [], // State to hold questions from API
      loading: true,  // State to track loading status
    };
  }

  componentDidMount() {
    this.fetchQuestions();
  }

  // Function to fetch questions from the API
  fetchQuestions = async () => {
    try {
      const response = await axios.get('https://ssserv.com/q.php'); // Replace with your API URL
      this.setState({ questions: response.data, loading: false });
    } catch (error) {
      console.error('Error fetching questions:', error);
      this.setState({ loading: false });
    }
  };

  // Function for menu items
  MenuNavigation = (menu_item) => {
    const { navigation } = this.props;

    if (menu_item === 'Home') {
      navigation.navigate('Home');
    } else if (menu_item === 'Website') {
      navigation.navigate('WebsiteQuoteForm', {
        itemId: menu_item,
        otherParam: 'anything you want here',
      });
    } else if (menu_item === 'APP') {
      navigation.navigate('APPQuoteForm', { itemId: menu_item });
    } else if (menu_item === 'Logo') {
      navigation.navigate('Logos', { itemId: menu_item });
    } else if (menu_item === 'Landingpage') {
      navigation.navigate('Landingpage', { itemId: menu_item });
    }
  };

  // Function for navigating to quote forms
  QuoteformNavigation = (service_type) => {
    const { navigation } = this.props;

    if (service_type === 'Website') {
      navigation.navigate('WebsiteQuoteForm', {
        itemId: service_type,
        otherParam: 'anything you want here',
      });
    } else if (service_type === 'APP') {
      navigation.navigate('APPQuoteForm', { itemId: service_type });
    } else if (service_type === 'Logo') {
      navigation.navigate('Logos', { itemId: service_type });
    } else if (service_type === 'Landingpage') {
      navigation.navigate('Landingpage', { itemId: service_type });
    }
  };

  // Header left icon
  headerleftIcon = () => (
    <View>
      <Icon name="menu" color="black" onPress={this.toggleOpen} />
    </View>
  );

  // Header center component
  headerCenter = () => (
    <View>
      <Image
        source={require('.././assets/applogo.png')}
        style={{ width: 250, height: 50, resizeMode: 'contain' }}
      />
    </View>
  );

  // Toggle drawer
  toggleOpen = () => {
    this.setState({ open: !this.state.open });
  };

  // Drawer content
  drawerContent = () => (
    <View style={styles.animatedBox}>
      <TouchableOpacity onPress={this.toggleOpen}>
        <Text>Close</Text>
      </TouchableOpacity>
      {this.state.menu.map((l, i) => (
        <ListItem
          style={{ width: 170, marginLeft: -20 }}
          key={i}
          bottomDivider
          onPress={() => this.MenuNavigation(l.name)}
        >
          <Icon name={l.icon} style={{ fontSize: 5 }} color="black" type="font-awesome" />
          <ListItem.Content>
            <ListItem.Title style={{ fontSize: 15, width: 270, marginRight: 100 }}>
              {l.name}
            </ListItem.Title>
          </ListItem.Content>
          <ListItem.Chevron />
        </ListItem>
      ))}
    </View>
  );

  render() {
    const {  questions, loading } = this.state;
    //const { visible, questions, loading } = this.state;

    return (
      <SafeAreaView>
       
        <View>
          <MenuDrawer
            open={this.state.open}
            drawerContent={this.drawerContent()}
            drawerPercentage={45}
            animationTime={250}
            overlay={true}
            opacity={0.4}
            style={{ backgroundColor: 'black' }}
         >
      

            {/* Swiper component for questions */}
            {loading ? (
  <View style={styles.loadingContainer}>
    <ActivityIndicator size="large" color="#1dbf73" />
  </View>
) : (
  <Swiper
  showsButtons={true}
  loop={false}
  showsPagination={true}
  dotStyle={{
    backgroundColor: 'rgba(0,0,0,.2)',
    width: 8,
    height: 8,
    borderRadius: 5,
    marginLeft: 3,
    marginRight: 3,
    marginTop: 3,
    marginBottom: 3,
  }}
  activeDotStyle={{
    backgroundColor: '#1dbf73',
    width: 8,
    height: 8,
    borderRadius: 5,
    marginLeft: 3,
    marginRight: 3,
    marginTop: 3,
    marginBottom: 3,
  }}
  paginationStyle={{
    bottom:130, // Position the bullets at the top
    left: 110,
    right: 100,
  }}
>
    {questions.map((item) => (
      <QuestionSlide key={item.id} item={item} />
    ))}
  </Swiper>
)}

          </MenuDrawer>
        </View>
      </SafeAreaView>
    );
  }
}

// Styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  animatedBox: {
    flex: 1,
    backgroundColor: 'white',
    padding: 10,
    opacity: 0.8,
  },
  slide: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f9c2ff',
    borderWidth: 5,
    margin: 30,
    marginBottom: 150,
  },
  category:{
    fontSize: 22,
    marginBottom: 10,
    textAlign: 'center',
    fontWeight:'bold',
  },
  question: {
    fontSize: 18,
    marginBottom: 10,
    textAlign: 'center',
  },
  answer: {
    fontSize: 16,
    color: 'gray',
    marginTop: 10,
    textAlign: 'center',
  },
  flashcardButton: {
    marginTop: 20,
    fontSize: 16,
    color: '#1dbf73',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
