import React, { Component } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import Swiper from 'react-native-swiper';

const questions = [
  { id: 1, question: 'What is the capital of France?', answer: 'Paris' },
  { id: 2, question: 'What is 2 + 2?', answer: '4' },
  { id: 3, question: 'Who wrote "To be, or not to be"?', answer: 'William Shakespeare' },
];

const QuestionSlide = ({ item }) => {

  const { category = "General", question = "No question provided", answer = "No answer available" } = item;

  const toggleAnswer = () => {
    setShowAnswer(!showAnswer);
  };

  return (
    <View style={styles.slide}>
      <Text style={styles.category}>{category}</Text>
      <Text style={styles.question}>{question}</Text>
      
    </View>
  );
};


class QuestionCarousel extends Component {
  render() {
    return (
      <Swiper showsButtons loop={false}>
        {questions.map((item) => (
          <QuestionSlide key={item.id} item={item} />
        ))}
      </Swiper>
    );
  }
}

const styles = StyleSheet.create({
  slide: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f9c2ff',
    borderWidth: 5,
    margin: 30,
  },
  question: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  answer: {
    fontSize: 16,
    color: '#333',
  },
  flashcardButton: {
    marginTop: 10,
    color: '#007BFF',
  },
});

export default QuestionCarousel;
