import React, { useState, useContext, useEffect } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';
import EditQuestionContext from './EditQuestionContext'; // Import context
import axios from 'axios';

const EditQuestionScreen = ({ route, navigation }) => {
  const { onSave } = useContext(EditQuestionContext); // Use context
  const [category, setCategory] = useState('');
  const [question, setQuestion] = useState('');

  useEffect(() => {
    if (route.params?.question) {
      const { category, question } = route.params.question;
      setCategory(category);
      setQuestion(question);
    }
  }, [route.params?.question]);

  const handleSave = async () => {
    try {
      await axios.post('https://webcruiser.in/update-question.php', { category, question });
      if (onSave) onSave(); // Call the function from context
      navigation.goBack();
    } catch (error) {
      console.error('Error saving question:', error);
    }
  };

  return (
    <View style={styles.container}>
      <Text>Edit Question</Text>
      <TextInput
        style={styles.input}
        value={category}
        onChangeText={setCategory}
        placeholder="Category"
      />
      <TextInput
        style={styles.input}
        value={question}
        onChangeText={setQuestion}
        placeholder="Question"
      />
      <Button title="Save" onPress={handleSave} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  input: {
    borderBottomWidth: 1,
    marginBottom: 20,
  },
});

export default EditQuestionScreen;
