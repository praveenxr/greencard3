import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, ActivityIndicator, TouchableOpacity, RefreshControl, Alert } from 'react-native';
import axios from 'axios';
import styles from './styles';
import { Ionicons } from '@expo/vector-icons';

const QuestionListScreen = ({ navigation }) => { // Access navigation from props
  const [questions, setQuestions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    fetchQuestions();
  }, []);

  const fetchQuestions = async () => {
    try {
      const response = await axios.get('https://webcruiser.in/q.php');
      setQuestions(response.data);
      setLoading(false);
      setRefreshing(false);
    } catch (error) {
      console.error('Error fetching questions:', error);
      setLoading(false);
      setRefreshing(false);
    }
  };

  const handleRefresh = () => {
    setRefreshing(true);
    fetchQuestions();
  };

  const onEdit = (item) => {
    navigation.navigate('EditQuestion', { questionItem: item, onSave: handleRefresh });
  };

  const onDelete = (item) => {
    Alert.alert(
      'Delete Question',
      'Are you sure you want to delete this question?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'OK',
          onPress: async () => {
            try {
              // Replace with your delete endpoint and method
              await axios.post('https://webcruiser.in/delete-question.php', { id: item.id });
              fetchQuestions(); // Refresh the list
            } catch (error) {
              console.error('Error deleting question:', error);
            }
          },
        },
      ],
      { cancelable: false }
    );
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#1dbf73" />
      </View>
    );
  }

  return (
    <FlatList
      data={questions}
      keyExtractor={(item) => item.id.toString()}
      renderItem={({ item }) => (
        <View style={styles.listItemContainer}>
          <View style={styles.buttonContainer}>
            <TouchableOpacity  onPress={() => onEdit(item)}>
              <Ionicons style={styles.listLconEdit} name="pencil" size={24} color="#1dbf73" />
            </TouchableOpacity>
            <TouchableOpacity onPress={() => onDelete(item)}>
              <Ionicons name="trash" size={24} color="#ff0000" />
            </TouchableOpacity>
          </View>
          <View style={styles.listItemContent}>
            <Text style={styles.category}>{item.category}</Text>
            <Text style={styles.questionTextList}>{item.question}</Text>
          </View>
        </View>
      )}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />
      }
    />
  );
};

export default QuestionListScreen;
